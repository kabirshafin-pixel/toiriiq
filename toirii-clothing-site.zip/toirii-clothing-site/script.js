const products = [
  {id:"01",name:"FORM / 01 TEE",detail:"Heavyweight cotton · Washed black",price:1850},
  {id:"02",name:"OFFSET TROUSER",detail:"Relaxed fit · Charcoal",price:2650},
  {id:"03",name:"AFTERFORM JACKET",detail:"Structured fleece · Onyx",price:4200},
  {id:"04",name:"STILL / LONGSLEEVE",detail:"Boxy silhouette · Bone",price:2250}
];
const cart = [];
const count = document.getElementById("cart-count");
const drawerCount = document.getElementById("drawer-count");
const overlay = document.getElementById("cart-overlay");
const cartItems = document.getElementById("cart-items");
const subtotal = document.getElementById("cart-subtotal");
const toast = document.getElementById("toast");
let toastTimer;

function money(value){return "৳ " + value.toLocaleString("en-BD");}
function showToast(message){
  toast.textContent = message; toast.classList.add("show");
  clearTimeout(toastTimer); toastTimer = setTimeout(()=>toast.classList.remove("show"),2100);
}
function renderCart(){
  const totalQty = cart.reduce((sum,item)=>sum+item.qty,0);
  const total = cart.reduce((sum,item)=>sum+item.price*item.qty,0);
  count.textContent = totalQty; drawerCount.textContent = `(${totalQty})`; subtotal.textContent = money(total);
  if(!cart.length){cartItems.innerHTML='<p class="empty-cart">Your bag is currently empty.</p>';return;}
  cartItems.innerHTML = cart.map(item=>`
    <div class="cart-line">
      <div><strong>${item.name}</strong><p>${item.detail} · Qty ${item.qty}</p></div>
      <div><strong>${money(item.price*item.qty)}</strong><br><button data-remove="${item.id}">REMOVE</button></div>
    </div>`).join("");
}
function addToCart(id){
  const product = products.find(p=>p.id===id); if(!product)return;
  const existing = cart.find(item=>item.id===id);
  if(existing) existing.qty++; else cart.push({...product,qty:1});
  renderCart(); showToast(`${product.name} ADDED TO BAG`);
}
function openCart(){overlay.classList.add("open");overlay.setAttribute("aria-hidden","false");document.body.style.overflow="hidden";}
function closeCart(){overlay.classList.remove("open");overlay.setAttribute("aria-hidden","true");document.body.style.overflow="";}
document.querySelectorAll(".quick-add").forEach(button=>button.addEventListener("click",()=>addToCart(button.dataset.id)));
document.querySelector(".cart-trigger").addEventListener("click",openCart);
document.getElementById("close-cart").addEventListener("click",closeCart);
document.querySelector(".cart-backdrop").addEventListener("click",closeCart);
cartItems.addEventListener("click",event=>{
  const id=event.target.dataset.remove;if(!id)return;
  const index=cart.findIndex(item=>item.id===id);if(index>-1)cart.splice(index,1);
  renderCart();
});
document.getElementById("checkout-button").addEventListener("click",()=>showToast("CHECKOUT IS NOT CONNECTED YET"));
document.querySelectorAll(".filter").forEach(button=>button.addEventListener("click",()=>{
  document.querySelectorAll(".filter").forEach(filter=>filter.classList.remove("active"));
  button.classList.add("active");
  const category=button.dataset.filter;
  document.querySelectorAll(".product-card").forEach(card=>{
    card.hidden=category!=="all" && card.dataset.category!==category;
  });
}));
const menuToggle=document.querySelector(".menu-toggle");
const nav=document.querySelector(".main-nav");
menuToggle.addEventListener("click",()=>{
  const open=nav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded",String(open));
});
nav.querySelectorAll("a").forEach(link=>link.addEventListener("click",()=>{nav.classList.remove("open");menuToggle.setAttribute("aria-expanded","false");}));
document.getElementById("newsletter-form").addEventListener("submit",event=>{
  event.preventDefault();
  document.getElementById("newsletter-message").textContent="THANK YOU — YOU'RE ON THE LIST.";
  event.target.reset();
});
document.addEventListener("keydown",event=>{if(event.key==="Escape")closeCart();});
renderCart();
